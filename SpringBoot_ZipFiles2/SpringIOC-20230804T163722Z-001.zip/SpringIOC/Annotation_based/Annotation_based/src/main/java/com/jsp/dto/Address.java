package com.jsp.dto;

import org.springframework.stereotype.Component;

@Component
public class Address {

}
