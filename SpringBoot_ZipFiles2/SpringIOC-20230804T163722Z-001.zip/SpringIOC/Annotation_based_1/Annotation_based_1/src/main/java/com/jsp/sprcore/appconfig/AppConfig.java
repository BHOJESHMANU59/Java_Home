package com.jsp.sprcore.appconfig;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = "com.jsp.sprcore")
@Configuration
public class AppConfig {

}
