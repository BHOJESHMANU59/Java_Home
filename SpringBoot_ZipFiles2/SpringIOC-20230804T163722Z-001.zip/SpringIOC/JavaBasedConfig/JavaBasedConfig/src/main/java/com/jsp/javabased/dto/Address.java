package com.jsp.javabased.dto;

public class Address {

}
