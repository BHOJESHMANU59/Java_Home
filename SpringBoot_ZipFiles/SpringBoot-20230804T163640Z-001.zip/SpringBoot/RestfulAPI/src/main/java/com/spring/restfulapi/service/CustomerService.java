package com.spring.restfulapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.spring.restfulapi.dto.Customer;
import com.spring.restfulapi.repository.CustomerDao;
import com.spring.restfulapi.response.ResponseStructure;

@Service
public class CustomerService {
	@Autowired
	private CustomerDao customerDao;

	public ResponseStructure<?> insertCustomer(Customer customer) {
		Customer customer2 = customerDao.insertCustomer(customer);	
		ResponseStructure<Customer> responseStructure = new ResponseStructure<>();	
		responseStructure.setData(customer2);
		responseStructure.setHttpStatus(HttpStatus.CREATED); //201
		return responseStructure;
	}
	
	public ResponseStructure<?> findAllCustomers(){
		List<Customer> customerList = customerDao.findAllCustomers();
		ResponseStructure<List<Customer>> responseStructure = new ResponseStructure<>();
		responseStructure.setData(customerList);
		responseStructure.setHttpStatus(HttpStatus.OK);
		return responseStructure;
	}
	
	public ResponseStructure<?> findCustById(int custId){
		Optional<Customer> findCustById = customerDao.findCustById(custId);	
		ResponseStructure<Customer> responseStructure = new ResponseStructure<>();
		Customer customer = findCustById.get();
		responseStructure.setData(customer);
		responseStructure.setHttpStatus(HttpStatus.OK);
		return responseStructure;	
	}
	
	public ResponseStructure<?> deleteCustomer(int custId){
		Customer customer = customerDao.deleteCustomer(custId);
		ResponseStructure<Customer> responseStructure = new ResponseStructure<>();
		responseStructure.setData(customer);
		responseStructure.setHttpStatus(HttpStatus.OK);	
		return responseStructure;
	}
	
	public ResponseStructure<?> updateCustomer(Customer customer){
		Customer customer2 = customerDao.updateCustomer(customer);
		ResponseStructure<Customer> responseStructure = new ResponseStructure<>();
		responseStructure.setData(customer2);
		responseStructure.setHttpStatus(HttpStatus.OK);
		return responseStructure;
	}
	
	public ResponseStructure<?> updatePhoneNumber(int custId, long phone){
		Customer customer = customerDao.updatePhoneNumber(custId, phone);
		ResponseStructure<Customer> responseStructure = new ResponseStructure<>();
		responseStructure.setData(customer);
		responseStructure.setHttpStatus(HttpStatus.OK);
		return responseStructure;
	}

}
