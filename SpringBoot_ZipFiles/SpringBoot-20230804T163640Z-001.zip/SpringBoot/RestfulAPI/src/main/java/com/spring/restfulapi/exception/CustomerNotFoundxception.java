package com.spring.restfulapi.exception;

public class CustomerNotFoundxception extends RuntimeException {
	public CustomerNotFoundxception(String message) {
		super(message);
	}
}
