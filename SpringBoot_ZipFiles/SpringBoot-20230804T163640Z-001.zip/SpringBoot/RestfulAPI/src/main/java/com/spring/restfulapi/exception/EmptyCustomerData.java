package com.spring.restfulapi.exception;

import net.bytebuddy.implementation.bind.annotation.Super;

public class EmptyCustomerData extends RuntimeException {
	public EmptyCustomerData(String message) {
		super(message);
	}
}
