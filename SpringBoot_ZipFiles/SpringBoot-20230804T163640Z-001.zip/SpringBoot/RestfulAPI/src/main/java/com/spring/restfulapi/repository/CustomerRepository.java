package com.spring.restfulapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.restfulapi.dto.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	
}
