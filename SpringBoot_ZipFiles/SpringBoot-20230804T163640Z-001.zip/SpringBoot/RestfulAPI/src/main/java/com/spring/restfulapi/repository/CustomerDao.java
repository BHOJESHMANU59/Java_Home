package com.spring.restfulapi.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties.Lettuce;
import org.springframework.stereotype.Repository;

import com.spring.restfulapi.dto.Customer;
import com.spring.restfulapi.exception.CustomerNotFoundxception;
import com.spring.restfulapi.exception.EmptyCustomerData;

@Repository
public class CustomerDao {
	
	@Autowired
	private CustomerRepository customerRepository;
	//SimpleJPARepository object -->CRUD operation methods implementation

	public Customer insertCustomer(Customer customer) {
		
		return customerRepository.save(customer);
	}
	
	public List<Customer> findAllCustomers() {
		List<Customer> findAllCust = customerRepository.findAll();
		
		if(findAllCust!=null) {
			return findAllCust;
		}
		throw new EmptyCustomerData("No Customer Details Found");

	}
	
	public Optional<Customer> findCustById(int custId) {
		Optional<Customer> findCust = customerRepository.findById(custId);
		
		if(findCust.isPresent()) {
			return findCust;
		}
		throw new CustomerNotFoundxception("Customer Id Not Found");
	}
	
	public Customer deleteCustomer(int custId) {
		Optional<Customer> findCustById = customerRepository.findById(custId);
		
		if(findCustById.isPresent()) {
			customerRepository.deleteById(custId);
			return findCustById.get();
		}
		 throw new CustomerNotFoundxception("Customer Id Not Found");
	}
	
	public Customer updateCustomer(Customer customer) {
		Optional<Customer> findCustomer =customerRepository.findById(customer.getCustId());
		
		if(findCustomer.isPresent()) {
			return customerRepository.save(customer);
		}
		throw new CustomerNotFoundxception("Customer Id not available for updation!");
	}
	
//	public Customer updateCustomer(Customer customer) {
//		Optional<Customer> findCustomer =customerRepository.findById(customer.getCustId());
//		
//		if(findCustomer.isPresent()) {
//			Customer cust = findCustomer.get();
//			cust.setCustId(customer.getCustId());
//			cust.setCustName(customer.getCustName());
//			cust.setPhone(customer.getPhone());
//			cust.setAddress(customer.getAddress());
//			cust.setCity(customer.getCity());
//			cust.setPincode(customer.getPincode());
//			return customerRepository.save(cust);
//		}
//		throw new CustomerNotFoundxception("Customer Id not available for updation!");
//	}
	
	public Customer updatePhoneNumber(int custId, long phone) {
		Optional<Customer> updatePhone=customerRepository.findById(custId);
		
		if(updatePhone.isPresent()) {
			Customer cust = updatePhone.get();
			cust.setPhone(phone);			
			return customerRepository.save(cust);
		}
		throw new CustomerNotFoundxception("Customer Id not available for updation!");
		
	}

}
