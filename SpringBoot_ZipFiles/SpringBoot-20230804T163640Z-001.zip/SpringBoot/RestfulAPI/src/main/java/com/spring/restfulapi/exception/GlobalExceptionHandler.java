package com.spring.restfulapi.exception;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(CustomerNotFoundxception.class)
	public ResponseEntity<?> handlerCustomerNotFoundxception(CustomerNotFoundxception exception, 
															HttpServletRequest request){
		APIError apiError =new APIError();
		apiError.setMessage(exception.getMessage());
		apiError.setLocalDateTime(LocalDateTime.now());
		apiError.setEndPoint(request.getRequestURI());
		apiError.setHttpStatus(HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<>(apiError, apiError.getHttpStatus());
	}
	
	@ExceptionHandler(EmptyCustomerData.class)
	public ResponseEntity<?> handlerEmptyCustomerData(EmptyCustomerData exception,
													HttpServletRequest request){
		APIError apiError =new APIError();
		apiError.setMessage(exception.getMessage());
		apiError.setLocalDateTime(LocalDateTime.now());
		apiError.setEndPoint(request.getRequestURI());
		apiError.setHttpStatus(HttpStatus.NO_CONTENT);
		
		return new ResponseEntity<>(apiError, apiError.getHttpStatus());
	}
}
