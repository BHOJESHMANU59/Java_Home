package com.spring.restfulapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.restfulapi.dto.Products;

public interface ProductRepo extends JpaRepository<Products, Integer>{

}
