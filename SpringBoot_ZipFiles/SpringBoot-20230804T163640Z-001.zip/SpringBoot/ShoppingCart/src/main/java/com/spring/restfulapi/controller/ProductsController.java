package com.spring.restfulapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.restfulapi.dto.Products;
import com.spring.restfulapi.response.ResponseStructure;
import com.spring.restfulapi.service.ProductsService;

@RestController
public class ProductsController {
	
	@Autowired
	private ProductsService productsService;
	
	@PostMapping(path = "/persist")
	public ResponseEntity<?> insertProducts(@RequestBody Products products){
		 ResponseStructure<?> responseStructure = productsService.insertProducts(products);
		 return new ResponseEntity<>(responseStructure, responseStructure.getHttpStatus());
	}
}
