package com.spring.restfulapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.spring.restfulapi.dto.Products;
import com.spring.restfulapi.repository.ProductsDao;
import com.spring.restfulapi.response.ResponseStructure;

public class ProductsService {
	
	@Autowired
	private ProductsDao productsDao;

	public ResponseStructure<?> insertProducts(Products products) {
		Products products2 = productsDao.insertProducts(products);
		ResponseStructure<Products> responseStructure = new ResponseStructure<>();
		responseStructure.setData(products2);
		responseStructure.setHttpStatus(HttpStatus.CREATED);
		return responseStructure; 
	}
}
