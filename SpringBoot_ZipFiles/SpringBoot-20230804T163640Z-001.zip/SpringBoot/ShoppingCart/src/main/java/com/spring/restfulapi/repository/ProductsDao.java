package com.spring.restfulapi.repository;

import org.springframework.beans.factory.annotation.Autowired;

import com.spring.restfulapi.dto.Products;
import com.spring.restfulapi.response.ResponseStructure;

public class ProductsDao {
	 
	@Autowired
	private ProductRepo productRepo;

	public Products insertProducts(Products products) {
		return productRepo.save(products);
	}
	
}

