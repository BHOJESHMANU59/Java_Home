package com.spring.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spring.user.dto.User;
import com.spring.user.response.ResponseStructure;
import com.spring.user.service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping(path = "/persist")
	public ResponseEntity<?> insertUser(@RequestBody User user){
		
		ResponseStructure<?> responseStructure=userService.insertUser(user);
		
		return new ResponseEntity<>(responseStructure, HttpStatus.OK);
	}
	
//	@GetMapping(path = "/fetch")
//	public ResponseEntity<?> getUser(@RequestParam int userId){
//		if(userId>=100) {
//			return new ResponseEntity<>("Valid User Id", HttpStatus.OK);
//		}
//		return new ResponseEntity<>("Invalid User Id", HttpStatus.NOT_FOUND);
//		}
//	
//	@DeleteMapping(path = "/delete/{userId}")
//	public ResponseEntity<?> deleteUser(@PathVariable int userId){
//		return new ResponseEntity<>("Deleted User", HttpStatus.OK);
//	}
}
