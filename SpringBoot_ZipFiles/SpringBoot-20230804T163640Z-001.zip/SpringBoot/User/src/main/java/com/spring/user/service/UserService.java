package com.spring.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.user.dto.User;
import com.spring.user.repository.UserDao;
import com.spring.user.response.ResponseStructure;

@Service
public class UserService {
	@Autowired
	private UserDao userDao;

	public ResponseStructure<?> insertUser(User user) {
		 User user2=userDao.insertUser(user);
		return null;
	}
}
