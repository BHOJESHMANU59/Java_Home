package com.spring.user.repository;

public interface UserRepository {

}
