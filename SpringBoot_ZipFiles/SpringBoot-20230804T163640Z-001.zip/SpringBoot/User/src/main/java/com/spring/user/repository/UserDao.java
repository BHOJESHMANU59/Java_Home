package com.spring.user.repository;

import org.springframework.stereotype.Repository;

import com.spring.user.dto.User;

@Repository
public class UserDao {

	public User insertUser(User user) {
		return null;
	}

}
