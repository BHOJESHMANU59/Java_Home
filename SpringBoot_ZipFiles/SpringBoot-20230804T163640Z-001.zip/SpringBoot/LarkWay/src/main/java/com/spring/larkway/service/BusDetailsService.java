package com.spring.larkway.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.spring.larkway.dto.BusDetails;
import com.spring.larkway.repository.BusDetailsDao;
import com.spring.larkway.response.ResponseStructure;

@Service
public class BusDetailsService {

	@Autowired
	private BusDetailsDao busDetailsDao;
	
	public ResponseStructure<?> insertBusDetails(BusDetails busDetails) {
		BusDetails busDetails2 = busDetailsDao.insertBusDetails(busDetails);
		ResponseStructure<BusDetails> responseStructure = new ResponseStructure<>();
		responseStructure.setData(busDetails2);
		responseStructure.setHttpStatus(HttpStatus.CREATED);
		return responseStructure;
	}

}
