package com.spring.larkway.response;

import org.springframework.http.HttpStatus;

import lombok.Data;

@Data
public class ResponseStructure<T> {
	private T data;
	private HttpStatus httpStatus;
}
