package com.spring.larkway.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class BusDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int busId;
	private String busKey;
	private String busName;
	private String busNumber;
	private int seats;
	private int bookedSeats;
	private String type;
	private String boardingPt;
	private String destnPt;
	private String start;
	private String end;
	private double price;
	private double rating;
	private int journeyTime;
}
