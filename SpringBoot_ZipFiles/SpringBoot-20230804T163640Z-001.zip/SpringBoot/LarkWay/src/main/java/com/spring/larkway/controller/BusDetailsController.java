package com.spring.larkway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.larkway.dto.BusDetails;
import com.spring.larkway.response.ResponseStructure;
import com.spring.larkway.service.BusDetailsService;

@RestController
public class BusDetailsController {
	
	@Autowired
	private BusDetailsService busDetailsService;
	
	@PostMapping(path="savebusdetails")
	public ResponseEntity<?> insertBusDetails(@RequestBody BusDetails busDetails){
		ResponseStructure<?> responseStructure = busDetailsService.insertBusDetails(busDetails);
		return new ResponseEntity<>(responseStructure, responseStructure.getHttpStatus());
	}
}
