package com.spring.larkway.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.larkway.dto.BusDetails;

@Repository
public class BusDetailsDao {
	
	@Autowired
	private BusDetailsRepo busDetailsRepo;
	
	public BusDetails insertBusDetails(BusDetails busDetails) {
		BusDetails saveBusdetails = busDetailsRepo.save(busDetails);
		return saveBusdetails;
	}

}
