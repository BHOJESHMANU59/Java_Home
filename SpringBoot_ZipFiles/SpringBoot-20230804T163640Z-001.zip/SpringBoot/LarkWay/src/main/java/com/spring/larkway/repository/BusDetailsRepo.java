package com.spring.larkway.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.larkway.dto.BusDetails;

public interface BusDetailsRepo extends JpaRepository<BusDetails, Integer> {

}
