package com.spring.restfulapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LarkWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
