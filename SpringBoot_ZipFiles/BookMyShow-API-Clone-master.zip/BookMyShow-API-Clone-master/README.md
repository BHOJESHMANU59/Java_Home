# BookMyShow-API-Clone
BookMyShow-API-Clone is a replication of Ticket Booking System API || collaborated work || technologies used - Spring boot, spring data Jpa, lombok and swagger
