package com.tyss.BookMyShowClone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
