package edu.project.bookmyshow.enums;

public enum ScreenAvailability {
	ALLOTTED,
	NOT_ALLOTTED
}
