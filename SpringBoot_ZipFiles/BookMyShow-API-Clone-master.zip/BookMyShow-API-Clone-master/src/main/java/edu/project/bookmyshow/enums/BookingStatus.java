package edu.project.bookmyshow.enums;

public enum BookingStatus {
	ACTIVE,
	EXPIRED,
	CANCELLED
}
