package edu.project.bookmyshow.enums;

public enum SeatType {
	
	CLASSIC,
	GOLD,
	PREMIUM
}
