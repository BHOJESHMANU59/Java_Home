package edu.project.bookmyshow.enums;

public enum ShowStatus {
	
	ACTIVE,
	ON_GOING,
	CLOSED,
	CANCELLED
}
