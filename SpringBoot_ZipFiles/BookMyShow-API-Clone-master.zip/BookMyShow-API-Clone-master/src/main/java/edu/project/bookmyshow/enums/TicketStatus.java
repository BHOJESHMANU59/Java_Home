package edu.project.bookmyshow.enums;

public enum TicketStatus {
	ACTIVE,
	EXPIRED,
	CANCELLED
}
