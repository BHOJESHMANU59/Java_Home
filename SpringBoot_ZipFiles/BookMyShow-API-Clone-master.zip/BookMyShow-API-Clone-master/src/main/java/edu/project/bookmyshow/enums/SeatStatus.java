package edu.project.bookmyshow.enums;

public enum SeatStatus {
	
	BLOCKED,
	AVAILABLE,
	BOOKED
}
