package edu.project.bookmyshow.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookingDto {
	private long bookingId;
	private double seatPrice;
}
