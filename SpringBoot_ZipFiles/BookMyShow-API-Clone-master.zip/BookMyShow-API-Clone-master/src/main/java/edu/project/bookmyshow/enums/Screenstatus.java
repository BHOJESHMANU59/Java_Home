package edu.project.bookmyshow.enums;

public enum Screenstatus {
	AVAILABLE,
	ALMOST_FULL,
	HOUSEFULL
}
