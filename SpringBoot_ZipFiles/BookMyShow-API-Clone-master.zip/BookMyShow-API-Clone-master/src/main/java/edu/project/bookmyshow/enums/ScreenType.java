package edu.project.bookmyshow.enums;

public enum ScreenType {
	
	TWO_DIMENSION,
	THREE_DIMENSION,
	IMAX_TWO_DIMENSION,
	IMAX_THREE_DIMENSION
}
